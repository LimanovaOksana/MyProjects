# APICollection
API collection to project https://gbcdn.mrgcdn.ru/uploads/asset/4593160/attachment/0c2b91bd5b8b4c450890cc70ef93a073.pdf
