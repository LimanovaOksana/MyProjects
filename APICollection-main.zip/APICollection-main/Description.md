
В рамках тестирования API для проекта https://gbcdn.mrgcdn.ru/uploads/asset/4593160/attachment/0c2b91bd5b8b4c450890cc70ef93a073.pdf была создана коллекция в Postman.

